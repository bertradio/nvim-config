-- blink-spell-extras.lua - from ChatGPT
-- Add-on only: keeps your existing blink.cmp look/behavior untouched.
-- Provides: LuaSnip + curated friendly-snippets + smart spell gating helpers
--          + Markdown comfort + tiny Bash/PowerShell snippets.

local function is_windows()
  local ok, uname = pcall(vim.loop.os_uname)
  return ok and uname and uname.sysname and uname.sysname:match('Windows')
end

-- Treesitter-aware helper: are we in a comment or string right now?
-- Expose globally so your existing blink config can call it if desired.
_G.BlinkInCommentOrString = function()
  local bufnr = vim.api.nvim_get_current_buf()
  local pos = vim.api.nvim_win_get_cursor(0)
  local row, col = pos[1] - 1, pos[2] -- 0-based for TS API
  local ok = pcall(require, 'vim.treesitter')
  if ok then
    local caps = vim.treesitter.get_captures_at_pos(bufnr, row, col) or {}
    for _, cap in ipairs(caps) do
      if cap.capture == 'comment' or cap.capture == 'string' then
        return true
      end
    end
  end
  -- Fallback to syntax groups
  local syn = vim.fn.synIDattr(vim.fn.synID(row + 1, col + 1, 1), 'name') or ''
  return syn:match('Comment') or syn:match('String') or false
end

return {
  -- Snippet engine + curated snippets (no Blink config here)
  {
    'L3MON4D3/LuaSnip',
    event = 'InsertEnter',
    build = (function()
      return is_windows() and nil or 'make install_jsregexp'
    end)(),
    opts = {
      history = true,
      updateevents = 'TextChanged,TextChangedI',
      enable_autosnippets = false,
      region_check_events = 'CursorMoved,CursorHold,InsertEnter',
      delete_check_events = 'TextChanged,InsertLeave',
    },
    config = function(_, opts)
      local ls = require('luasnip')
      ls.config.setup(opts)

      local vs = require('luasnip.loaders.from_vscode')
      -- Curated packs only
      pcall(vs.lazy_load, { include = { 'lua', 'markdown', 'shellscript', 'powershell' } })

      -- User snippets
      local user_snips = vim.fn.stdpath('config') .. '/snippets'
      if vim.fn.isdirectory(user_snips) == 1 then
        pcall(vs.lazy_load, { paths = { user_snips } })
      end

      -- Tiny extras
      local s = ls.snippet
      local t = ls.text_node
      local i = ls.insert_node

      ls.add_snippets('sh', {
        s('shb', {
          t({
            '#!/usr/bin/env bash',
            'set -euo pipefail',
            "IFS=$'\\n\\t'",
            '',
          }),
          t({ '# ' }),
          i(1, 'script description'),
          t({ '', '', 'main() {', '  ' }),
          i(2, '# TODO'),
          t({ '', '}', '', 'main "$@"' }),
        }),
      })
      ls.add_snippets('bash', ls.get_snippets('sh'))
      ls.add_snippets('zsh', ls.get_snippets('sh'))

      ls.add_snippets('ps1', {
        s('param', {
          t({ '[CmdletBinding()]', 'param(', '    ' }),
          i(1, '[string]$Path = "."'),
          t({ '', ')', '', 'begin {', '    ' }),
          i(2, '# init'),
          t({ '', '}', '', 'process {', '    ' }),
          i(3, '# work'),
          t({ '', '}', '', 'end {', '    ' }),
          i(4, '# cleanup'),
          t({ '', '}' }),
        }),
      })
      ls.add_snippets('powershell', ls.get_snippets('ps1'))

      -- Non-conflicting snippet keys
      local map_opts = { expr = true, silent = true, desc = 'LuaSnip jump/expand' }
      vim.keymap.set({ 'i', 's' }, '<C-j>', function()
        return ls.expand_or_jumpable() and '<Plug>luasnip-expand-or-jump' or '<C-j>'
      end, map_opts)
      vim.keymap.set({ 'i', 's' }, '<C-k>', function()
        return ls.jumpable(-1) and '<Plug>luasnip-jump-prev' or '<C-k>'
      end, map_opts)
      vim.keymap.set('i', '<C-l>', function()
        return ls.choice_active() and '<Plug>luasnip-next-choice' or '<C-l>'
      end, map_opts)
    end,
    dependencies = { 'rafamadriz/friendly-snippets' },
  },

  -- Comfort tweaks (no UI changes to Blink)
  {
    'nvim-lua/plenary.nvim',
    event = 'VeryLazy',
    config = function()
      -- Markdown comfort
      vim.api.nvim_create_autocmd('FileType', {
        pattern = { 'markdown' },
        callback = function()
          vim.opt_local.conceallevel = 2
          vim.opt_local.wrap = true
          vim.opt_local.linebreak = true
        end,
        desc = 'Markdown comfort settings',
      })

      -- Shell UX
      vim.api.nvim_create_autocmd('FileType', {
        pattern = { 'sh', 'bash', 'zsh' },
        callback = function()
          vim.opt_local.iskeyword:append('-')
        end,
        desc = 'Shell editing comfort',
      })
    end,
  },
}
