-- blink-spell.lua - blink.cmp with smart spelling + cmdline & search completion
-- Updated: 2025-09-03 from ChatGPT

return {
  'saghen/blink.cmp',
  version = '1.*',
  dependencies = {
    'rafamadriz/friendly-snippets',
    'nvim-lua/plenary.nvim',
    'ribru17/blink-cmp-spell',
    'L3MON4D3/LuaSnip',
  },

  opts = {
    keymap = { preset = 'super-tab' },

    appearance = {
      use_nvim_cmp_as_default = true,
      nerd_font_variant = 'mono',
    },

    signature = { enabled = true, window = { border = 'rounded' } },

    completion = {
      menu = {
        border = 'rounded',
        draw = {
          columns = {
            { 'label', 'label_description', gap = 1 },
            { 'kind_icon' },
            -- { 'kind' },
            { 'source_name' }, -- keep visible; you decided to leave "Text"
          },
        },
      },
      documentation = { auto_show = true, window = { border = 'rounded' } },
      trigger = { show_in_snippet = false },
      list = { selection = { preselect = false, auto_insert = false } },
    },

    sources = {
      -- Keep default lean; spell is added explicitly in prose filetypes
      default = { 'buffer', 'path' },

      per_filetype = {
        -- Code-like: LSP/snippets first; spell appears only in comments/strings via context gate
        lua = { 'buffer', 'lsp', 'path', 'snippets' },
        sh = { 'buffer', 'lsp', 'path', 'snippets' },
        ps1 = { 'lsp', 'buffer', 'path', 'snippets' },
        python = { 'buffer', 'lsp', 'path', 'snippets' },
        javascript = { 'buffer', 'lsp', 'path', 'snippets' },
        typescript = { 'buffer', 'lsp', 'path', 'snippets' },

        -- Prose-like: spell first, then buffer, then path
        markdown = { 'spell', 'buffer', 'path' },
        text = { 'spell', 'buffer', 'path' },
        gitcommit = { 'spell', 'buffer', 'path' },
        rst = { 'spell', 'buffer', 'path' },
        latex = { 'spell', 'buffer', 'path' },
      },

      providers = {
        -- Make buffer *not* a fallback of LSP so it always shows
        lsp = {
          score_offset = 3,
          fallbacks = {}, -- <-- key change
        },
        buffer = {
          score_offset = 10,
          min_keyword_length = 2, -- tweak to taste
          -- If you want only current buffer:
          opts = {
            get_bufnrs = function()
              return { vim.api.nvim_get_current_buf() }
            end,
          },
        },
        path = { score_offset = 2 },
        snippets = { score_offset = 1 },
        cmdline = { score_offset = 1 },

        spell = {
          name = 'Spell',
          module = 'blink-cmp-spell',
          score_offset = 3,
          opts = {
            max_entries = 5,
            preselect_current_word = false,
            keep_all_entries = false,
            use_cmp_spell_sorting = true,
            -- enable_in_context is set in config() so prose is always on, code is TS-gated
          },
        },
      },
    },

    -- Your fuzzy settings
    fuzzy = {
      implementation = 'prefer_rust_with_warning',
      use_frecency = true,
      use_proximity = true,
      prebuilt_binaries = { download = true },
    },
  },

  config = function(_, opts)
    -- 1) TS-aware check for comments/strings in code buffers
    local function in_comment_or_string()
      local ok, ts = pcall(require, 'vim.treesitter')
      if not ok then
        return false
      end
      local bufnr = 0
      local pos = vim.api.nvim_win_get_cursor(0)
      local row, col = pos[1] - 1, pos[2]
      local ok_caps, caps = pcall(ts.get_captures_at_pos, bufnr, row, col)
      if not ok_caps or not caps then
        return false
      end
      for _, cap in ipairs(caps) do
        local name = cap.capture or cap
        if name == 'nospell' or name == '@nospell' then
          return false
        end
        if name == 'comment' or name == 'string' or name == '@comment' or name == '@string' then
          return true
        end
      end
      return false
    end

    -- 2) Always-on for prose; TS-gated in code
    local prose_fts_set = {
      markdown = true,
      text = true,
      gitcommit = true,
      rst = true,
      latex = true,
    }
    local function enable_spell_context()
      local ft = vim.bo.filetype
      if prose_fts_set[ft] then
        return true
      end
      return in_comment_or_string()
    end

    if opts and opts.sources and opts.sources.providers and opts.sources.providers.spell then
      opts.sources.providers.spell.opts.enable_in_context = enable_spell_context
    end

    -- 3) Apply Blink setup
    require('blink.cmp').setup(opts)

    -- 4) Blink on command-line ":" and search "/" "?"
    pcall(function()
      local cmdline = require('blink.cmp.cmdline')
      if cmdline and cmdline.setup then
        cmdline.setup({
          cmdline = { enabled = true },
          search = { enabled = true },
        })
      end
    end)

    -- 5) Prose-friendly spell settings (turn spell on, set lang + spellfile)
    local SPELL_LANGS = { 'en' } -- add 'he' etc. if needed
    local spellfile_path = vim.fs.normalize(
      vim.fn.stdpath('config') .. '/spell/' .. (SPELL_LANGS[1] or 'en') .. '.utf-8.add'
    )
    do
      local dir = vim.fs.dirname(spellfile_path)
      if dir and vim.fn.isdirectory(dir) == 0 then
        vim.fn.mkdir(dir, 'p')
      end
    end

    vim.api.nvim_create_autocmd('FileType', {
      pattern = { 'markdown', 'text', 'gitcommit', 'rst', 'latex' },
      callback = function()
        vim.opt_local.spell = true
        vim.opt_local.spelllang = SPELL_LANGS
        vim.opt_local.spellfile = spellfile_path
      end,
      desc = 'Enable spell with configured languages and spellfile for prose buffers',
    })

    -- Optional: explicitly keep spell off for common code buffers
    vim.api.nvim_create_autocmd('FileType', {
      pattern = {
        'bash',
        'c',
        'cpp',
        'go',
        'java',
        'javascript',
        'jsx',
        'kotlin',
        'lua',
        'ps1',
        'python',
        'rust',
        'sh',
        'tsx',
        'typescript',
        'zsh',
      },
      callback = function()
        vim.opt_local.spell = false
      end,
      desc = 'Disable spell for code buffers',
    })
  end,
}
